package bookshopsystem.bookshop.constants;

public class GlobalConstants {
    public static final String BOOK_PATH_FILE = "src/main/resources/books.txt";
    public static final String AUTHOR_PATH_FILE = "src/main/resources/authors.txt";
    public static final String CATEGORIES_PATH_FILE = "src/main/resources/categories.txt";
}
