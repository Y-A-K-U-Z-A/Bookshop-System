package bookshopsystem.bookshop.utils;

import bookshopsystem.bookshop.entities.Author;
import bookshopsystem.bookshop.entities.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.*;
import java.util.LinkedHashSet;
import java.util.Set;

@Component
public class FileUtilImpl implements FileUtil{
    private BufferedReader reader ;

    @Autowired
    public FileUtilImpl(){

    }
    @Override
    public String[] readFileContent(String filePath) throws IOException {
        File file = new File(filePath);

        reader = new BufferedReader(new FileReader(file));

        Set<String> result = new LinkedHashSet<>();
        String line ;

        while ((line = reader.readLine()) != null){
            if (!"".equals(line)){
                result.add(line);
            }
        }

        return result.toArray(String[]::new);
    }
    @Override
    public void printBook(Book book, int ex){
        if (ex == 2){
        System.out.println(book.getTitle() + " " + book.getReleaseDate() + " " + book.getCopies());
        }else {
            System.out.println(book.getTitle());
        }
    }

    @Override
    public void printAuthor(Author a, int ex) {
        if (ex == 2){
            System.out.println(a.getFirstName() + " " + a.getLastName()  + " with " + a.getBooks().size() + " books count");
        }else {
            System.out.println(a.getFirstName() + " " + a.getLastName());
        }
    }
}
