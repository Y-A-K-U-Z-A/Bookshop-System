package bookshopsystem.bookshop.utils;

import bookshopsystem.bookshop.entities.Author;
import bookshopsystem.bookshop.entities.Book;

import java.io.FileNotFoundException;
import java.io.IOException;

public interface FileUtil {
    String[] readFileContent(String filePath) throws IOException;
    void printBook(Book book, int ex);

    void printAuthor(Author a, int ex);
}
