package bookshopsystem.bookshop.controller;

import bookshopsystem.bookshop.constants.*;
import bookshopsystem.bookshop.entities.Book;
import bookshopsystem.bookshop.entities.Category;
import bookshopsystem.bookshop.services.AuthorService;
import bookshopsystem.bookshop.services.BookService;
import bookshopsystem.bookshop.services.CategoryService;
import bookshopsystem.bookshop.utils.FileUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import static bookshopsystem.bookshop.constants.GlobalConstants.CATEGORIES_PATH_FILE;

@Controller
public class AppController implements CommandLineRunner {
    private final CategoryService categoryService;
    private final AuthorService authorService;
    private final BookService bookService;

    @Autowired
    public AppController(CategoryService categoryService, AuthorService authorService, BookService bookService) {
        this.categoryService = categoryService;
        this.authorService = authorService;
        this.bookService = bookService;
    }

    @Override
    public void run(String... args) throws Exception {
        //Set authors & categories after seeding the books.
//
//        this.categoryService.seedCategories();
//        this.authorService.seedAuthors();
//        this.bookService.seedBooks();

        this.bookService.getBooksAfter();
        this.authorService.getAuthorsAtLeastOneBook();
        this.authorService.getAuthorsOrderedByBooks();
        this.bookService.getBooksWithAuthor();


    }
}
