package bookshopsystem.bookshop.repositories;

import bookshopsystem.bookshop.entities.Author;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface AuthorRepository extends JpaRepository<Author, Long> {
    List<Author> findAll();

    //2.Get all authors with at least one book with release date before 1990. Print their first name and last name.
    @Query("select a from Author a join a.books b where b.releaseDate < ?1 and a.books.size >= 1")
    List<Author> getAuthorByBooksAfter(LocalDate year);

    //3.Get all authors, ordered by the number of their books (descending). Print their first name, last name and book count.
    @Query("select a from Author a order by a.books.size desc")
    List<Author> getAuthorByBooksCount();
}
