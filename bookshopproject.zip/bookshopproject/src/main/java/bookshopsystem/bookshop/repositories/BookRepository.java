package bookshopsystem.bookshop.repositories;

import bookshopsystem.bookshop.entities.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.time.Year;
import java.util.List;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {
    boolean existsByTitle(String title);

    List<Book> findBookByReleaseDateAfter(LocalDate year);
    //4.Get all books from author George Powell, ordered by their release date (descending), then by book title (ascending). Print the book's title, release date and copies.
    @Query("select b from Book b where concat(b.author.firstName, ' ', b.author.lastName) = ?1 order by b.releaseDate desc , b.title asc")
    List<Book> findBookByAuthorFirstNameAndAuthorLastNameOrderByReleaseDateDescAndBookTitle(String fullName);


}
