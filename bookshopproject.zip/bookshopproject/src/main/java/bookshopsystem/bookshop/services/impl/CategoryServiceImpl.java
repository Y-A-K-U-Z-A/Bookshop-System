package bookshopsystem.bookshop.services.impl;

import bookshopsystem.bookshop.constants.GlobalConstants;
import bookshopsystem.bookshop.entities.Book;
import bookshopsystem.bookshop.entities.Category;
import bookshopsystem.bookshop.repositories.CategoryRepository;
import bookshopsystem.bookshop.services.CategoryService;
import bookshopsystem.bookshop.utils.FileUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import static bookshopsystem.bookshop.constants.GlobalConstants.CATEGORIES_PATH_FILE;

@Service
public class CategoryServiceImpl implements CategoryService {
    private final FileUtil fileUtil;
    private CategoryRepository categoryRepository;

    @Autowired
    public CategoryServiceImpl(FileUtil fileUtil, CategoryRepository categoryRepository) {
        this.fileUtil = fileUtil;
        this.categoryRepository = categoryRepository;
    }

    @Override
    public void seedCategories() throws IOException {
        String[] categories = fileUtil.readFileContent(CATEGORIES_PATH_FILE);

        for (String nameCategory : categories) {
            if (!existCategory(nameCategory)) {
                this.categoryRepository.saveAndFlush(new Category(nameCategory));
            }
        }
    }

    @Override
    public Category getCategory(long id) {
        return categoryRepository.getCategoriesById(id);
    }

    @Override
    public void setBooksInCategories(Book book, List<Category> categories) {
        for (Category c : categories) {
            c.addBook(book);
            categoryRepository.saveAndFlush(c);
        }
    }

    private boolean existCategory(String nameCategory) {
        return categoryRepository.existsByName(nameCategory);
    }


}
