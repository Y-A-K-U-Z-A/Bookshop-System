package bookshopsystem.bookshop.services.impl;

import bookshopsystem.bookshop.entities.*;
import bookshopsystem.bookshop.repositories.BookRepository;
import bookshopsystem.bookshop.services.AuthorService;
import bookshopsystem.bookshop.services.BookService;
import bookshopsystem.bookshop.services.CategoryService;
import bookshopsystem.bookshop.utils.FileUtil;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import static bookshopsystem.bookshop.constants.GlobalConstants.BOOK_PATH_FILE;

@Service
@Transactional
public class BookServiceImpl implements BookService {
    private final FileUtil fileUtil;
    private final CategoryService categoryService;
    private final AuthorService authorService;
    private final BookRepository bookRepository;

    public BookServiceImpl(FileUtil fileUtil, CategoryService categoryService, AuthorService authorService, BookRepository bookRepository) {
        this.fileUtil = fileUtil;
        this.categoryService = categoryService;
        this.authorService = authorService;
        this.bookRepository = bookRepository;
    }


    @Override
    public void seedBooks() throws IOException {
        String[] books = this.fileUtil.readFileContent(BOOK_PATH_FILE);

        if (this.bookRepository.count() != 0 ){
            return;
        }

        for (String b : books) {
            String[] bookInfo = b.split("\\s+");
            Author author = getRandomAuthor();
            EditionType[] editionType = EditionType.values();
            EditionType type = editionType[Integer.parseInt(bookInfo[0])];
            LocalDate releaseDate = getReleaseDate(bookInfo[1]);
            int copies = Integer.parseInt(bookInfo[2]);
            BigDecimal price = BigDecimal.valueOf(Double.parseDouble(bookInfo[3]));
            AgeRestriction[] age = AgeRestriction.values();
            AgeRestriction ageRestriction = age[Integer.parseInt(bookInfo[4])];

            String title = "";
            for (int i = 5; i < bookInfo.length; i++) {
                title += bookInfo[i] + " ";
            }

            bookRepository.save(new Book(title, null, type, price, copies, releaseDate,
                    ageRestriction, author, getCategories()));
            bookRepository.flush();
        }
    }


    @Override
    public void getBooksAfter() {
        LocalDate year = LocalDate.of(2000, 1, 1);
        List<Book> list = this.bookRepository.findBookByReleaseDateAfter(year);
        System.out.println("\t\t\t\tEXERCISE 1");
        list.forEach(b -> fileUtil.printBook(b, 1));
    }

    @Override
    public void getBooksWithAuthor() {
        System.out.println("\t\t\t\tEXERCISE 4");
        this.bookRepository.findBookByAuthorFirstNameAndAuthorLastNameOrderByReleaseDateDescAndBookTitle("George Powell")
                .forEach(b -> fileUtil.printBook(b, 2));
    }

    @Override
    public Book getSingleBook(long id) {
        return this.bookRepository.getOne(id);
    }

    @Transactional
    public Author getRandomAuthor() {
        Random random = new Random();
        int randomId = random.nextInt(this.authorService.getAllAuthorsCount()) + 1;
        return authorService.getAuthorById(randomId);
    }

    private Set<Category> getCategories() {
        Set<Category> result = new LinkedHashSet<>();
        Random random = new Random();
        int bound = random.nextInt(3) + 1;

        for (int i = 1; i <= bound; i++) {
            int categoryId = random.nextInt(8) + 1;
            result.add(this.categoryService.getCategory(categoryId));
        }
        return result;
    }

    private LocalDate getReleaseDate(String string) {
        int[] date = Arrays.stream(string.split("/")).mapToInt(Integer::parseInt).toArray();
        return LocalDate.of(date[2], date[1], date[0]);
    }
}
