package bookshopsystem.bookshop.services;

import bookshopsystem.bookshop.entities.Book;

import java.io.IOException;

public interface BookService {
    void seedBooks() throws IOException;



    void getBooksAfter();

    void getBooksWithAuthor();

    Book getSingleBook(long id);
}
