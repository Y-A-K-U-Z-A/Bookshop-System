package bookshopsystem.bookshop.services.impl;

import bookshopsystem.bookshop.constants.GlobalConstants;
import bookshopsystem.bookshop.entities.Author;
import bookshopsystem.bookshop.entities.Book;
import bookshopsystem.bookshop.repositories.AuthorRepository;
import bookshopsystem.bookshop.services.AuthorService;
import bookshopsystem.bookshop.utils.FileUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

@Service
public class AuthorServiceImpl implements AuthorService {
    private final FileUtil fileUtil;
    private final AuthorRepository authorRepository;

    @Autowired
    public AuthorServiceImpl(FileUtil fileUtil, AuthorRepository authorRepository) {
        this.fileUtil = fileUtil;
        this.authorRepository = authorRepository;
    }


    @Override
    public void seedAuthors() throws IOException {
        String[] authors = fileUtil.readFileContent(GlobalConstants.AUTHOR_PATH_FILE);

        Arrays.stream(authors)
                .forEach(a -> {
                    String[] info = a.split("\\s+");
                    authorRepository.saveAndFlush(new Author(info[0], info[1]));
                });
    }

    @Override
    public List<Author> getAllAuthors() {
        return authorRepository.findAll();
    }

    @Override
    public int getAllAuthorsCount() {
        return (int) this.authorRepository.count();
    }

    @Override
    public Author getAuthorById(long randomId) {
        return this.authorRepository.getOne(randomId);
    }

    //3.Get all authors, ordered by the number of their books (descending). Print their first name, last name and book count.

    public void getAuthorsOrderedByBooks(){
        System.out.println("\t\t\t\tEXERCISE 3");
        this.authorRepository.getAuthorByBooksCount()
        .forEach(a -> fileUtil.printAuthor(a, 2));
    }

    @Override
    public void addBookToAuthor(Author randomAuthor, Book book) {
        Author author = authorRepository.getOne(randomAuthor.getId());
        author.addBook(book);
        authorRepository.saveAndFlush(author);
    }

    //2.Get all authors with at least one book with release date before 1990. Print their first name and last name.

    public void getAuthorsAtLeastOneBook(){
        System.out.println("\t\t\t\tEXERCISE 2");
        this.authorRepository.getAuthorByBooksAfter(LocalDate.of(1990, 1, 1))
                .forEach(a -> fileUtil.printAuthor(a, 1));;
    }

}










