package bookshopsystem.bookshop.services;

import bookshopsystem.bookshop.entities.Book;
import bookshopsystem.bookshop.entities.Category;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;

public interface CategoryService {
    void seedCategories() throws IOException;

    Category getCategory(long id);

    void setBooksInCategories(Book book, List<Category> collect);
}
