package bookshopsystem.bookshop.entities;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "authors")
@NoArgsConstructor
public class Author extends BaseEntity{
    @Column(name = "first_name") @Getter @Setter
    private String firstName;

    @Column(name = "last_name", nullable = false) @Getter @Setter
    private String lastName;

    @OneToMany(mappedBy = "author", fetch = FetchType.EAGER) @Getter @Setter
    private Set<Book> books;

    public Author(String firstName, String lastName){
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public void addBook(Book book){
        this.books.add(book);
    }


}
