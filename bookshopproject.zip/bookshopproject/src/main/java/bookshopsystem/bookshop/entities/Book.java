package bookshopsystem.bookshop.entities;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Set;

@Entity
@Table(name = "books")
@NoArgsConstructor
@AllArgsConstructor
public class Book extends BaseEntity{
    @Column(name = "title", nullable = false, length = 50) @Getter @Setter
    private String title;

    @Column(name = "description", length = 1000) @Getter @Setter
    private String description;

    @Column(name = "edition_type", nullable = false) @Getter @Setter
    @Enumerated(value = EnumType.ORDINAL)
    private EditionType type;

    @Column(name = "price", nullable = false) @Getter @Setter
    private BigDecimal price;

    @Column(name = "copies", nullable = false) @Getter @Setter
    private int copies;

    @Column(name = "release_date") @Getter @Setter
    private LocalDate releaseDate;

    @Column(name = "age_restriction", nullable = false) @Getter @Setter
    @Enumerated(value = EnumType.ORDINAL)
    private AgeRestriction ageRestriction;

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
     @Getter @Setter
    private Author author;

    @ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER) @Getter @Setter
    private Set<Category> categories;

}
