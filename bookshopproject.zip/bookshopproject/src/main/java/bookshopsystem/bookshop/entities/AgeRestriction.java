package bookshopsystem.bookshop.entities;

public enum AgeRestriction {
    MINOR, TEEN, ADULT;
}
