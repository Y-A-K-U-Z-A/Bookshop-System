package bookshopsystem.bookshop.entities;

public enum EditionType {
    NORMAL, PROMO,GOLD;
}
