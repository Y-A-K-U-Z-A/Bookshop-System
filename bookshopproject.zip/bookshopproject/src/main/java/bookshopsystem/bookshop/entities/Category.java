package bookshopsystem.bookshop.entities;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import java.util.Set;

@Entity
@Table(name = "categories")
@NoArgsConstructor
public class Category extends BaseEntity{
    @Column(name = "names", nullable = false, unique = true) @Getter @Setter
    private String name;

    @ManyToMany(mappedBy = "categories") @Getter @Setter
    private Set<Book> books;

    public Category(String name){
        this.name = name;
    }

    public void addBook(Book book){
        this.books.add(book);
    }
}
